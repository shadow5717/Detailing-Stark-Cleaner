import { MainLayout } from "@/src/components/layout/MainLayout"

export default function Page() {
  return <MainLayout />
}
