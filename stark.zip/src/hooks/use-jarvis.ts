"use client"

// Hook for integrating Jarvis AI across modules
import { useEffect, useCallback } from "react"
import { getVoiceManager, type VoiceState } from "@/lib/voice-manager"
import { speak } from "@/lib/jarvis-ai"

export interface UseJarvisOptions {
  onCommand?: (command: string) => void
  onNavigate?: (module: string, tab?: string) => void
  autoEnable?: boolean
}

export function useJarvis(options: UseJarvisOptions = {}) {
  const { onCommand, onNavigate, autoEnable = false } = options
  const voiceManager = getVoiceManager()

  const startListening = useCallback(() => {
    voiceManager.startListening()
  }, [voiceManager])

  const stopListening = useCallback(() => {
    voiceManager.stopListening()
  }, [voiceManager])

  const toggleListening = useCallback(() => {
    voiceManager.toggleListening()
  }, [voiceManager])

  const sendMessage = useCallback(
    (text: string) => {
      if (onCommand) {
        onCommand(text)
      }
    },
    [onCommand],
  )

  const sayText = useCallback((text: string) => {
    speak(text)
  }, [])

  useEffect(() => {
    const handleStateChange = (state: VoiceState) => {
      // Handle state changes if needed
    }

    const handleCommandExecuted = (data: any) => {
      if (data.response?.action === "navigate" && onNavigate && data.response.data) {
        const { module, tab } = data.response.data
        onNavigate(module, tab)
      }
    }

    voiceManager.on("state-changed", handleStateChange)
    voiceManager.on("command-executed", handleCommandExecuted)

    if (autoEnable) {
      startListening()
    }

    return () => {
      voiceManager.off("state-changed", handleStateChange)
      voiceManager.off("command-executed", handleCommandExecuted)
    }
  }, [voiceManager, onNavigate, autoEnable, startListening])

  return {
    startListening,
    stopListening,
    toggleListening,
    sendMessage,
    sayText,
  }
}
