"use client"

// Hook for business analytics and insights
import { useCallback, useState, useEffect } from "react"
import { generatePredictions, getAdminInsights } from "@/lib/jarvis-ai"
import { calculateMetrics } from "@/lib/business-analytics"
import { generateAdminReport, predictNextWeekTrends } from "@/lib/admin-ai"

export function useBusinessAnalytics() {
  const [metrics, setMetrics] = useState<any>(null)
  const [predictions, setPredictions] = useState<any>(null)
  const [insights, setInsights] = useState<any>(null)
  const [adminReport, setAdminReport] = useState<any>(null)
  const [weeklyTrends, setWeeklyTrends] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(false)

  const loadAnalytics = useCallback(async () => {
    setIsLoading(true)
    try {
      const [met, pred, ins, rep, trends] = await Promise.all([
        calculateMetrics(),
        generatePredictions(),
        getAdminInsights(),
        generateAdminReport(),
        predictNextWeekTrends(),
      ])

      setMetrics(met)
      setPredictions(pred)
      setInsights(ins)
      setAdminReport(rep)
      setWeeklyTrends(trends)
    } catch (error) {
      console.error("Error loading analytics:", error)
    }
    setIsLoading(false)
  }, [])

  useEffect(() => {
    loadAnalytics()
    // Refresh every 5 minutes
    const interval = setInterval(loadAnalytics, 5 * 60 * 1000)
    return () => clearInterval(interval)
  }, [loadAnalytics])

  return {
    metrics,
    predictions,
    insights,
    adminReport,
    weeklyTrends,
    isLoading,
    refresh: loadAnalytics,
  }
}
