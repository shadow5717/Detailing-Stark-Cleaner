"use client"

// Hook for Smart POS features
import { useCallback, useState, useEffect } from "react"
import type { Product } from "@/lib/db"
import {
  suggestComplementaryProducts,
  analyzeBarcodeScan,
  detectSalesAnomalies,
  recommendReordering,
} from "@/lib/smart-pos"

export function useSmartPOS() {
  const [suggestions, setSuggestions] = useState<any[]>([])
  const [anomalies, setAnomalies] = useState<string[]>([])
  const [reorderSuggestions, setReorderSuggestions] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(false)

  const getSuggestions = useCallback(async (cartItemIds: number[]) => {
    setIsLoading(true)
    try {
      const sug = await suggestComplementaryProducts(cartItemIds)
      setSuggestions(sug)
    } catch (error) {
      console.error("Error getting suggestions:", error)
    }
    setIsLoading(false)
  }, [])

  const checkAnomalies = useCallback(async () => {
    setIsLoading(true)
    try {
      const anom = await detectSalesAnomalies()
      setAnomalies(anom)
    } catch (error) {
      console.error("Error checking anomalies:", error)
    }
    setIsLoading(false)
  }, [])

  const getReorderSuggestions = useCallback(async () => {
    setIsLoading(true)
    try {
      const sugg = await recommendReordering()
      setReorderSuggestions(sugg)
    } catch (error) {
      console.error("Error getting reorder suggestions:", error)
    }
    setIsLoading(false)
  }, [])

  const analyzeBarcode = useCallback(async (barcode: string, existingProducts: Product[]) => {
    try {
      const result = await analyzeBarcodeScan(barcode, existingProducts)
      return result
    } catch (error) {
      console.error("Error analyzing barcode:", error)
      return {}
    }
  }, [])

  useEffect(() => {
    checkAnomalies()
    getReorderSuggestions()
  }, [checkAnomalies, getReorderSuggestions])

  return {
    suggestions,
    anomalies,
    reorderSuggestions,
    isLoading,
    getSuggestions,
    analyzeBarcode,
  }
}
