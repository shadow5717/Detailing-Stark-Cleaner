# Jarvis IA - Sistema de Inteligencia Artificial Empresarial

## Visión General

Jarvis es un asistente de inteligencia artificial que transforma STARK CLEANE en una plataforma empresarial inteligente. Funciona como Siri/Alexa para tu negocio, permitiendo control por voz, análisis predictivo y automatización.

## Características Principales

### 1. Control por Voz (Speech Recognition & Synthesis)
- **Web Speech API**: Reconocimiento de voz en español (es-DO)
- **Text-to-Speech**: Respuestas de voz natural
- **Flotante de Micrófono**: Botón accesible en cualquier momento

**Uso:**
\`\`\`typescript
import { useJarvis } from '@/hooks/use-jarvis';

const { startListening, stopListening } = useJarvis({
  onNavigate: (module, tab) => console.log(`Navegar a ${module}`)
});

startListening(); // Activar micrófono
\`\`\`

### 2. Motor de Comandos Inteligentes
- Procesamiento de lenguaje natural en español
- 20+ patrones de intención reconocidos
- Ejecución automática de acciones

**Comandos Disponibles:**
\`\`\`
"Abre el POS" → Navegar a Billar > POS
"Agenda una cita" → Navegar a Barbería > Citas
"Registra un vehículo" → Navegar a Car Wash > Registro
"Muéstrame las ventas" → Mostrar reportes de ventas
"Stock bajo" → Alertas de inventario
"Ayuda" → Mostrar comandos disponibles
\`\`\`

### 3. IA Predictiva de Negocio
- Análisis de tendencias de ventas
- Predicciones de productos populares
- Identificación de horas pico
- Recomendaciones de reabastecimiento

**Acceso:**
\`\`\`typescript
import { useBusinessAnalytics } from '@/hooks/use-business-analytics';

const { metrics, predictions, adminReport } = useBusinessAnalytics();
\`\`\`

### 4. POS Inteligente
- Sugerencias de productos complementarios basadas en historial
- Detección de códigos de barras incompletos
- Alertas de anomalías en ventas
- Recomendaciones automáticas de reabastecimiento

**Uso:**
\`\`\`typescript
import { useSmartPOS } from '@/hooks/use-smart-pos';

const { getSuggestions, analyzeBarcode } = useSmartPOS();
await getSuggestions([productId1, productId2]); // Sugerencias
\`\`\`

### 5. Asistente Administrativo
- Reporte diario automático
- Análisis de desempeño
- Alertas de problemas
- Recomendaciones de negocio

## Arquitectura de Ficheros

\`\`\`
src/
├── lib/
│   ├── jarvis-ai.ts              # Motor central IA
│   ├── voice-manager.ts          # Gestión de voz
│   ├── business-analytics.ts     # Análisis de negocio
│   ├── smart-pos.ts              # POS inteligente
│   └── admin-ai.ts               # Asistente admin
├── components/jarvis/
│   ├── JarvisButton.tsx           # Botón flotante
│   ├── JarvisPanel.tsx            # Panel de análisis
│   └── JarvisChat.tsx             # Interfaz de chat
├── modules/
│   └── Jarvis.tsx                 # Módulo principal
└── hooks/
    ├── use-jarvis.ts              # Hook de voz
    ├── use-smart-pos.ts           # Hook de POS
    └── use-business-analytics.ts  # Hook de analytics
\`\`\`

## Componentes Disponibles

### JarvisButton
Botón flotante para acceso rápido a comandos de voz
\`\`\`tsx
import { JarvisButton } from '@/components/jarvis/JarvisButton';
<JarvisButton onNavigate={(module) => {}} />
\`\`\`

### JarvisPanel
Panel de análisis e insightes en tiempo real
\`\`\`tsx
import { JarvisPanel } from '@/components/jarvis/JarvisPanel';
<JarvisPanel />
\`\`\`

### JarvisChat
Interfaz de chat para comandos
\`\`\`tsx
import { JarvisChat } from '@/components/jarvis/JarvisChat';
<JarvisChat />
\`\`\`

## Integración en Módulos Existentes

Para añadir sugerencias de Jarvis a un módulo:

\`\`\`typescript
import { useBusinessAnalytics } from '@/hooks/use-business-analytics';

function MyModule() {
  const { predictions } = useBusinessAnalytics();

  return (
    <div>
      {/* Tu contenido */}
      {predictions?.nextPopularProduct && (
        <Alert>
          Próximo producto popular: {predictions.nextPopularProduct}
        </Alert>
      )}
    </div>
  );
}
\`\`\`

## Comandos por Voz Completos

### Barbería
- "Agenda una cita"
- "Muéstra citas"
- "Historial barbería"

### Billar (POS)
- "Abre el POS"
- "Crear producto"
- "Ver inventario"
- "Stock bajo"

### Car Wash
- "Registra vehículo"
- "Vehículos en proceso"
- "Vehículos entregados"

### Sistema
- "Dashboard"
- "Configuración"
- "Ayuda"
- "Reportes"
- "Ventas del día"

## Tecnologías Utilizadas

- **Web Speech API**: Reconocimiento y síntesis de voz
- **IndexedDB**: Almacenamiento local de datos
- **Machine Learning Ligero**: Análisis de patrones
- **TypeScript**: Tipado estático
- **React**: Interfaz de usuario

## Performance y Optimización

- Análisis predictivo cacheado (30 segundos)
- Reconocimiento de voz optimizado para español
- IndexedDB indexado para búsquedas rápidas
- Componentes memo-izados para evitar re-renders

## Debugging

Habilita logs de debug:
\`\`\`typescript
// En console del navegador
localStorage.setItem('jarvis-debug', 'true');
\`\`\`

## Futuras Mejoras

- [ ] Integración con OpenAI GPT para NLP avanzado
- [ ] Exportación de reportes a PDF
- [ ] Integración con WhatsApp para alertas
- [ ] Dashboard móvil dedicado
- [ ] Análisis de sentimiento de clientes
- [ ] Predicción de demanda avanzada

---

**Versión**: 1.0.0  
**Estado**: Producción  
**Mantenedor**: Sistema STARK
