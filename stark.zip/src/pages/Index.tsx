import { MainLayout } from '@/components/layout/MainLayout';

const Index = () => {
  return <MainLayout />;
};

export default Index;
