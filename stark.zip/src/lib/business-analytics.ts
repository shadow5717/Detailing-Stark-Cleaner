// Business Intelligence & Predictive Analytics

import { getAllData, STORES, type Sale, type Product, type Vehicle, type Appointment } from "./db"

export interface BusinessMetrics {
  revenue: number
  salesCount: number
  avgTicket: number
  topProducts: Array<{ name: string; quantity: number; revenue: number }>
  topBarbers: Array<{ name: string; appointments: number; revenue: number }>
  vehicleMetrics: { total: number; avgTime: number; revenue: number }
  predictions: {
    nextPopularProduct: string | null
    peakHours: string[]
    recommendedRestocking: string[]
  }
}

export const calculateMetrics = async (): Promise<BusinessMetrics> => {
  const [sales, products, vehicles, appointments] = await Promise.all([
    getAllData<Sale>(STORES.SALES),
    getAllData<Product>(STORES.PRODUCTS),
    getAllData<Vehicle>(STORES.VEHICLES),
    getAllData<Appointment>(STORES.APPOINTMENTS),
  ])

  // Revenue calculations
  const totalRevenue = sales.reduce((sum, s) => sum + s.total, 0)
  const avgTicket = sales.length > 0 ? totalRevenue / sales.length : 0

  // Top products analysis
  const productStats: Record<string, { name: string; quantity: number; revenue: number }> = {}
  sales.forEach((sale) => {
    sale.productos.forEach((p) => {
      if (!productStats[p.id]) {
        productStats[p.id] = { name: p.nombre, quantity: 0, revenue: 0 }
      }
      productStats[p.id].quantity += p.cantidad
      productStats[p.id].revenue += p.cantidad * p.precio
    })
  })

  const topProducts = Object.values(productStats)
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 5)

  // Barber performance
  const barberStats: Record<string, { name: string; appointments: number; revenue: number }> = {}
  appointments.forEach((apt) => {
    if (!barberStats[apt.barbero]) {
      barberStats[apt.barbero] = { name: apt.barbero, appointments: 0, revenue: 0 }
    }
    barberStats[apt.barbero].appointments += 1
    barberStats[apt.barbero].revenue += apt.precio
  })

  const topBarbers = Object.values(barberStats)
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 5)

  // Vehicle metrics
  const totalVehicles = vehicles.length
  const totalVehicleRevenue = vehicles.reduce((sum, v) => sum + v.precio, 0)
  const avgVehicleTime = totalVehicles > 0 ? 45 : 0 // minutes

  // Predictions
  const predictions = generatePredictions(sales, products, vehicles, appointments)

  return {
    revenue: totalRevenue,
    salesCount: sales.length,
    avgTicket,
    topProducts,
    topBarbers,
    vehicleMetrics: {
      total: totalVehicles,
      avgTime: avgVehicleTime,
      revenue: totalVehicleRevenue,
    },
    predictions,
  }
}

const generatePredictions = (sales: Sale[], products: Product[], vehicles: Vehicle[], appointments: Appointment[]) => {
  const predictions = {
    nextPopularProduct: null as string | null,
    peakHours: [] as string[],
    recommendedRestocking: [] as string[],
  }

  // Find next popular product based on sales trends
  const productFrequency: Record<number, number> = {}
  sales.slice(-20).forEach((sale) => {
    sale.productos.forEach((p) => {
      productFrequency[p.id] = (productFrequency[p.id] || 0) + 1
    })
  })

  const mostFrequent = Object.entries(productFrequency).sort(([, a], [, b]) => b - a)[0]

  if (mostFrequent) {
    const product = products.find((p) => p.id === Number(mostFrequent[0]))
    if (product) predictions.nextPopularProduct = product.nombre
  }

  // Find peak hours
  const hourFrequency: Record<string, number> = {}
  sales.forEach((sale) => {
    const hour = sale.hora.split(":")[0]
    hourFrequency[hour] = (hourFrequency[hour] || 0) + 1
  })

  predictions.peakHours = Object.entries(hourFrequency)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 3)
    .map(([hour]) => `${hour}:00`)

  // Restocking recommendations
  predictions.recommendedRestocking = products
    .filter((p) => p.stock < 5)
    .map((p) => `${p.nombre} (${p.stock} unidades)`)

  return predictions
}
