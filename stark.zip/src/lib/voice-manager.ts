// Voice Management System - Centralized voice control

import { initSpeechRecognition, parseCommand, executeCommand, speak } from "./jarvis-ai"

export interface VoiceState {
  isListening: boolean
  transcript: string
  confidence: number
  lastCommand?: string
  lastResponse?: string
}

class VoiceManager {
  private recognition: any = null
  private state: VoiceState = {
    isListening: false,
    transcript: "",
    confidence: 0,
  }
  private listeners: Map<string, Function[]> = new Map()

  constructor() {
    this.recognition = initSpeechRecognition()
    if (this.recognition) {
      this.setupRecognitionListeners()
    }
  }

  private setupRecognitionListeners() {
    if (!this.recognition) return

    this.recognition.onstart = () => {
      this.updateState({ isListening: true, transcript: "" })
      this.emit("listening-started")
    }

    this.recognition.onresult = async (event: any) => {
      let transcript = ""
      for (let i = event.resultIndex; i < event.results.length; i++) {
        transcript += event.results[i][0].transcript
      }

      this.updateState({ transcript })
      this.emit("transcript-update", { transcript })

      // Process final result
      if (event.results[event.results.length - 1].isFinal) {
        console.log("[VoiceManager] Final transcript:", transcript)
        await this.processVoiceCommand(transcript)
      }
    }

    this.recognition.onerror = (event: any) => {
      console.error("[VoiceManager] Recognition error:", event.error)
      this.emit("error", { error: event.error })
      this.updateState({ isListening: false })
    }

    this.recognition.onend = () => {
      this.updateState({ isListening: false })
      this.emit("listening-ended")
    }
  }

  private async processVoiceCommand(transcript: string) {
    try {
      // Parse command
      const command = parseCommand(transcript)
      console.log("[VoiceManager] Parsed command:", command)

      // Execute command
      const response = await executeCommand(command)

      // Update state
      this.updateState({
        lastCommand: transcript,
        lastResponse: response.text,
      })

      // Emit response event
      this.emit("command-executed", { command, response })

      // Speak response
      if (response.shouldSpeak !== false) {
        speak(response.text)
      }

      // Execute action if needed
      if (response.action) {
        this.emit("action-required", { action: response.action, data: response.data })
      }
    } catch (error) {
      console.error("[VoiceManager] Error processing command:", error)
      speak("Disculpa, ocurrió un error")
      this.emit("error", { error })
    }
  }

  public startListening() {
    if (!this.recognition) {
      console.warn("[VoiceManager] Speech Recognition not available")
      return
    }
    if (!this.state.isListening) {
      this.recognition.start()
    }
  }

  public stopListening() {
    if (this.recognition && this.state.isListening) {
      this.recognition.abort()
    }
  }

  public toggleListening() {
    this.state.isListening ? this.stopListening() : this.startListening()
  }

  public getState(): VoiceState {
    return { ...this.state }
  }

  private updateState(partial: Partial<VoiceState>) {
    this.state = { ...this.state, ...partial }
    this.emit("state-changed", this.state)
  }

  // Event system
  private emit(event: string, data?: unknown) {
    const handlers = this.listeners.get(event) || []
    handlers.forEach((handler) => handler(data))
  }

  public on(event: string, handler: Function) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, [])
    }
    this.listeners.get(event)!.push(handler)
  }

  public off(event: string, handler: Function) {
    const handlers = this.listeners.get(event) || []
    const index = handlers.indexOf(handler)
    if (index > -1) {
      handlers.splice(index, 1)
    }
  }
}

// Singleton instance
let voiceManagerInstance: VoiceManager | null = null

export const getVoiceManager = (): VoiceManager => {
  if (!voiceManagerInstance) {
    voiceManagerInstance = new VoiceManager()
  }
  return voiceManagerInstance
}
