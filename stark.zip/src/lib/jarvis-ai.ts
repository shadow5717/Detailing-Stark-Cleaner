// JARVIS AI - Core Intelligence Engine
// Handles voice recognition, command processing, and AI-powered automation

import { getAllData, STORES, type Product, type Appointment, type Vehicle, type Sale } from "./db"

export interface JarvisCommand {
  intent: string
  action: string
  params: Record<string, unknown>
  confidence: number
}

export interface JarvisResponse {
  text: string
  action?: string
  data?: unknown
  shouldSpeak?: boolean
}

// Speech Recognition Setup
export const initSpeechRecognition = () => {
  const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
  if (!SpeechRecognition) {
    console.error("[Jarvis] Speech Recognition not supported in this browser")
    return null
  }
  const recognition = new SpeechRecognition()
  recognition.continuous = false
  recognition.interimResults = true
  recognition.lang = "es-DO"
  return recognition
}

// Text-to-Speech
export const speak = (text: string) => {
  if (!("speechSynthesis" in window)) {
    console.error("[Jarvis] Text-to-Speech not supported")
    return
  }

  // Cancel any ongoing speech
  window.speechSynthesis.cancel()

  const utterance = new SpeechSynthesisUtterance(text)
  utterance.lang = "es-DO"
  utterance.rate = 0.95
  utterance.pitch = 1
  utterance.volume = 1

  window.speechSynthesis.speak(utterance)
}

// Advanced Intent Recognition using NLP patterns
export const parseCommand = (text: string): JarvisCommand => {
  const input = text.toLowerCase().trim()

  // Remove common filler words
  const cleanedInput = input
    .replace(/jarvis[,\s]*/i, "")
    .replace(/por favor/gi, "")
    .replace(/puedes/gi, "")
    .trim()

  // Command patterns with weights
  const patterns = {
    // Barbería commands
    agenda_cita: {
      regex: /agenda|agende|crear?.*cita|nueva cita|reserv/i,
      intent: "barberia.appointment",
      action: "create_appointment",
    },
    lista_citas: {
      regex: /muestra?.*citas|lista.*citas|ver citas/i,
      intent: "barberia.list",
      action: "list_appointments",
    },
    historial_barberia: {
      regex: /historial.*barberia|citas pasadas|citas completadas/i,
      intent: "barberia.history",
      action: "history_appointments",
    },

    // Billar/POS commands
    nuevo_producto: {
      regex: /crear?.*producto|nuevo producto|agregar producto/i,
      intent: "billar.product",
      action: "create_product",
    },
    punto_venta: {
      regex: /abre?.*pos|punto de venta|venta|nueva venta|caja/i,
      intent: "billar.pos",
      action: "open_pos",
    },
    inventario: {
      regex: /inventario|stock|productos|muestra?.*stock/i,
      intent: "billar.inventory",
      action: "open_inventory",
    },
    bajo_stock: {
      regex: /stock bajo|productos bajos|alertas|sin stock/i,
      intent: "billar.alerts",
      action: "check_low_stock",
    },

    // Car Wash commands
    registrar_vehiculo: {
      regex: /registr|nuevo.*vehiculo|entrado.*vehiculo|auto entrante|carro nuevo/i,
      intent: "carwash.vehicle",
      action: "register_vehicle",
    },
    vehiculos_proceso: {
      regex: /vehiculos.*proceso|en proceso|lavando/i,
      intent: "carwash.inprogress",
      action: "list_vehicles_inprogress",
    },
    vehiculos_entregados: {
      regex: /entregados|completados|listos|vehiculos listos/i,
      intent: "carwash.completed",
      action: "list_vehicles_completed",
    },

    // Reports & Analytics
    reportes: {
      regex: /reportes?|estadisticas|analytics|analisis|resumen/i,
      intent: "analytics.reports",
      action: "generate_reports",
    },
    ventas_dia: {
      regex: /ventas.*dia|hoy|ventas hoy|ingresos/i,
      intent: "analytics.sales",
      action: "sales_today",
    },

    // Navigation
    dashboard: {
      regex: /inicio|dashboard|panel|home/i,
      intent: "nav.dashboard",
      action: "go_dashboard",
    },
    configuracion: {
      regex: /configuracion|ajustes|settings|preferencias/i,
      intent: "nav.settings",
      action: "go_settings",
    },

    // System commands
    ayuda: {
      regex: /ayuda|help|comandos|que puedes hacer|como funciona/i,
      intent: "system.help",
      action: "show_help",
    },
    voz: {
      regex: /activa?.*voz|reconocimiento|escucha|listening/i,
      intent: "system.voice",
      action: "toggle_voice",
    },
  }

  // Find matching pattern
  for (const [key, pattern] of Object.entries(patterns)) {
    if (pattern.regex.test(cleanedInput)) {
      return {
        intent: pattern.intent,
        action: pattern.action,
        params: { originalText: input },
        confidence: 0.85,
      }
    }
  }

  // Fallback: generic intent
  return {
    intent: "generic.query",
    action: "process_generic",
    params: { query: input },
    confidence: 0.3,
  }
}

// Execute commands based on parsed intent
export const executeCommand = async (command: JarvisCommand): Promise<JarvisResponse> => {
  const { action, params } = command

  try {
    switch (action) {
      // Barbería
      case "create_appointment":
        return {
          text: "Abriendo formulario de citas para barbería",
          action: "navigate",
          data: { module: "barberia", tab: "appointments" },
          shouldSpeak: true,
        }
      case "list_appointments":
        const appointments = await getAllData<Appointment>(STORES.APPOINTMENTS)
        return {
          text: `Encontré ${appointments.length} citas registradas. Abriendo lista...`,
          action: "navigate",
          data: { module: "barberia", tab: "appointments" },
          shouldSpeak: true,
        }

      // Billar
      case "create_product":
        return {
          text: "Abriendo formulario para crear nuevo producto",
          action: "navigate",
          data: { module: "billar", tab: "inventory" },
          shouldSpeak: true,
        }
      case "open_pos":
        return {
          text: "Abriendo punto de venta",
          action: "navigate",
          data: { module: "billar", tab: "pos" },
          shouldSpeak: true,
        }
      case "check_low_stock":
        const products = await getAllData<Product>(STORES.PRODUCTS)
        const lowStockProducts = products.filter((p) => p.stock < 10)
        const message =
          lowStockProducts.length > 0
            ? `Tengo ${lowStockProducts.length} productos con stock bajo`
            : "Todos los productos tienen stock adecuado"
        return {
          text: message,
          action: "show_data",
          data: { products: lowStockProducts },
          shouldSpeak: true,
        }

      // Car Wash
      case "register_vehicle":
        return {
          text: "Abriendo formulario para registrar vehículo",
          action: "navigate",
          data: { module: "carwash", tab: "register" },
          shouldSpeak: true,
        }

      // Navigation
      case "go_dashboard":
        return {
          text: "Vamos al dashboard",
          action: "navigate",
          data: { module: "dashboard" },
          shouldSpeak: true,
        }
      case "go_settings":
        return {
          text: "Abriendo configuración",
          action: "navigate",
          data: { module: "settings" },
          shouldSpeak: true,
        }

      // Help
      case "show_help":
        return {
          text: "Puedes decirme: agenda una cita, abre el POS, registra un vehículo, muéstrame las ventas, o abre el inventario",
          action: "show_help",
          shouldSpeak: true,
        }

      case "process_generic":
        return {
          text: "No entendí bien ese comando. ¿Qué deseas hacer?",
          action: "show_help",
          shouldSpeak: true,
        }

      default:
        return {
          text: "Comando no reconocido",
          shouldSpeak: true,
        }
    }
  } catch (error) {
    console.error("[Jarvis] Error executing command:", error)
    return {
      text: "Ocurrió un error al ejecutar el comando",
      shouldSpeak: true,
    }
  }
}

// Predictive Analytics Engine
export const generatePredictions = async () => {
  try {
    const sales = await getAllData<Sale>(STORES.SALES)
    const products = await getAllData<Product>(STORES.PRODUCTS)
    const appointments = await getAllData<Appointment>(STORES.APPOINTMENTS)

    // Calculate insights
    const totalRevenue = sales.reduce((sum, s) => sum + s.total, 0)
    const avgSaleValue = sales.length > 0 ? totalRevenue / sales.length : 0

    // Get top products
    const productSales: Record<number, { name: string; quantity: number; revenue: number }> = {}
    sales.forEach((sale) => {
      sale.productos.forEach((p) => {
        if (!productSales[p.id]) {
          productSales[p.id] = { name: p.nombre, quantity: 0, revenue: 0 }
        }
        productSales[p.id].quantity += p.cantidad
        productSales[p.id].revenue += p.cantidad * p.precio
      })
    })

    const topProducts = Object.entries(productSales)
      .sort(([, a], [, b]) => b.revenue - a.revenue)
      .slice(0, 5)

    // Low stock predictions
    const lowStockAlerts = products.filter((p) => p.stock < 5)

    return {
      totalRevenue,
      avgSaleValue,
      totalSales: sales.length,
      topProducts,
      lowStockAlerts,
      totalAppointments: appointments.length,
    }
  } catch (error) {
    console.error("[Jarvis] Error generating predictions:", error)
    return null
  }
}

// Smart suggestions for POS
export const suggestRelatedProducts = async (productId: number): Promise<Product[]> => {
  try {
    const sales = await getAllData<Sale>(STORES.SALES)
    const products = await getAllData<Product>(STORES.PRODUCTS)

    // Find products frequently bought together
    const relatedProducts: Record<number, number> = {}

    sales.forEach((sale) => {
      const hasProduct = sale.productos.some((p) => p.id === productId)
      if (hasProduct) {
        sale.productos.forEach((p) => {
          if (p.id !== productId) {
            relatedProducts[p.id] = (relatedProducts[p.id] || 0) + 1
          }
        })
      }
    })

    // Get top related products
    const suggestions = Object.entries(relatedProducts)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 3)
      .map(([id]) => products.find((p) => p.id === Number(id)))
      .filter(Boolean) as Product[]

    return suggestions
  } catch (error) {
    console.error("[Jarvis] Error suggesting products:", error)
    return []
  }
}

// Admin Dashboard Insights
export const getAdminInsights = async () => {
  try {
    const [sales, products, appointments, vehicles] = await Promise.all([
      getAllData<Sale>(STORES.SALES),
      getAllData<Product>(STORES.PRODUCTS),
      getAllData<Appointment>(STORES.APPOINTMENTS),
      getAllData<Vehicle>(STORES.VEHICLES),
    ])

    const today = new Date().toISOString().split("T")[0]
    const todaySales = sales.filter((s) => s.fecha === today)
    const todayAppointments = appointments.filter((a) => a.fecha === today)
    const todayVehicles = vehicles.filter((v) => v.fecha === today)

    // Potential issues
    const alerts = []

    if (products.some((p) => p.stock === 0)) {
      alerts.push("Hay productos sin stock")
    }
    if (products.some((p) => p.stock < 5)) {
      alerts.push("Varios productos con stock bajo")
    }
    if (todayVehicles.length > 10) {
      alerts.push("Alto volumen de vehículos hoy")
    }

    return {
      todayStats: {
        sales: todaySales.length,
        revenue: todaySales.reduce((sum, s) => sum + s.total, 0),
        appointments: todayAppointments.length,
        vehicles: todayVehicles.length,
      },
      alerts,
      recommendations: generateRecommendations(products, sales, appointments),
    }
  } catch (error) {
    console.error("[Jarvis] Error getting admin insights:", error)
    return null
  }
}

// Generate business recommendations
const generateRecommendations = (products: Product[], sales: Sale[], appointments: Appointment[]): string[] => {
  const recommendations = []

  // Low inventory alerts
  const criticalStock = products.filter((p) => p.stock < 3)
  if (criticalStock.length > 0) {
    recommendations.push(`Reabastecer ${criticalStock.length} producto(s)`)
  }

  // Sales patterns
  if (sales.length > 10) {
    const avgSale = sales.reduce((sum, s) => sum + s.total, 0) / sales.length
    recommendations.push(`Promedio de venta: RD$${avgSale.toFixed(2)}`)
  }

  return recommendations
}
