// Smart POS - Intelligent Point of Sale System
// Suggests products, detects patterns, and optimizes sales

import { getAllData, STORES, type Sale, type Product } from "./db"

export interface SmartPosRecommendation {
  productId: number
  productName: string
  reason: string
  confidence: number
  quantitySuggested?: number
}

export interface BarcodeScannerAI {
  suggestedCorrection?: string
  detectedDuplicate?: boolean
  matchedProduct?: Product
}

// Suggest related products based on purchase history
export const suggestComplementaryProducts = async (
  cartItems: number[],
  maxSuggestions = 3,
): Promise<SmartPosRecommendation[]> => {
  try {
    const [sales, products] = await Promise.all([getAllData<Sale>(STORES.SALES), getAllData<Product>(STORES.PRODUCTS)])

    const relatedProducts: Record<number, { count: number; product: Product; reasons: string[] }> = {}

    // Analyze purchase patterns
    sales.forEach((sale) => {
      const cartHasItems = cartItems.some((itemId) => sale.productos.some((p) => p.id === itemId))

      if (cartHasItems) {
        sale.productos.forEach((p) => {
          if (!cartItems.includes(p.id)) {
            if (!relatedProducts[p.id]) {
              const product = products.find((pr) => pr.id === p.id)
              relatedProducts[p.id] = {
                count: 0,
                product: product!,
                reasons: [],
              }
            }
            relatedProducts[p.id].count++
          }
        })
      }
    })

    // Generate recommendations
    const recommendations: SmartPosRecommendation[] = Object.values(relatedProducts)
      .sort((a, b) => b.count - a.count)
      .slice(0, maxSuggestions)
      .map(({ product, count }) => ({
        productId: product.id,
        productName: product.nombre,
        reason: `Frecuentemente comprado junto (${count} veces)`,
        confidence: Math.min(0.95, (count / sales.length) * 10),
        quantitySuggested: 1,
      }))

    return recommendations
  } catch (error) {
    console.error("[SmartPOS] Error generating recommendations:", error)
    return []
  }
}

// AI-powered barcode scanner correction
export const analyzeBarcodeScan = async (
  scannedCode: string,
  existingProducts: Product[],
): Promise<BarcodeScannerAI> => {
  const result: BarcodeScannerAI = {}

  // Check for duplicates (same code scanned twice)
  const isDuplicate = existingProducts.some((p) => p.codigo.toLowerCase() === scannedCode.toLowerCase())
  if (isDuplicate) {
    result.detectedDuplicate = true
    return result
  }

  // Fuzzy matching for incomplete/incorrect scans
  const similarProducts = existingProducts.filter((p) => {
    const similarity = calculateStringSimilarity(p.codigo.toLowerCase(), scannedCode.toLowerCase())
    return similarity > 0.7
  })

  if (similarProducts.length > 0) {
    result.suggestedCorrection = similarProducts[0].codigo
    result.matchedProduct = similarProducts[0]
  }

  return result
}

// Calculate string similarity (Levenshtein distance)
const calculateStringSimilarity = (str1: string, str2: string): number => {
  const longer = str1.length > str2.length ? str1 : str2
  const shorter = str1.length > str2.length ? str2 : str1

  if (longer.length === 0) return 1.0

  const editDistance = getEditDistance(longer, shorter)
  return (longer.length - editDistance) / longer.length
}

// Helper function for Levenshtein distance
const getEditDistance = (s1: string, s2: string): number => {
  const costs: number[] = []
  for (let i = 0; i <= s1.length; i++) {
    let lastValue = i
    for (let j = 0; j <= s2.length; j++) {
      if (i === 0) {
        costs[j] = j
      } else if (j > 0) {
        let newValue = costs[j - 1]
        if (s1.charAt(i - 1) !== s2.charAt(j - 1)) {
          newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1
        }
        costs[j - 1] = lastValue
        lastValue = newValue
      }
    }
    if (i > 0) costs[s2.length] = lastValue
  }
  return costs[s2.length]
}

// Detect anomalies in sales patterns
export const detectSalesAnomalies = async (): Promise<string[]> => {
  try {
    const sales = await getAllData<Sale>(STORES.SALES)

    if (sales.length < 5) return []

    const alerts: string[] = []

    // Check for unusually large transactions
    const avgSale = sales.reduce((sum, s) => sum + s.total, 0) / sales.length
    const largeTransactions = sales.filter((s) => s.total > avgSale * 3)
    if (largeTransactions.length > 0) {
      alerts.push(`${largeTransactions.length} transacción(es) inusualmente grande(s)`)
    }

    // Check for duplicate products in same transaction
    sales.forEach((sale) => {
      const productIds = sale.productos.map((p) => p.id)
      const hasDuplicates = new Set(productIds).size !== productIds.length
      if (hasDuplicates) {
        alerts.push("Detectado: mismo producto duplicado en transacción")
      }
    })

    return alerts
  } catch (error) {
    console.error("[SmartPOS] Error detecting anomalies:", error)
    return []
  }
}

// Suggest inventory reordering based on sales velocity
export const recommendReordering = async (): Promise<
  Array<{
    productName: string
    currentStock: number
    recommendedOrder: number
    urgency: "critical" | "high" | "medium"
  }>
> => {
  try {
    const [sales, products] = await Promise.all([getAllData<Sale>(STORES.SALES), getAllData<Product>(STORES.PRODUCTS)])

    const last30Days = sales.filter((s) => {
      const saleDate = new Date(s.fecha)
      const thirtyDaysAgo = new Date()
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)
      return saleDate >= thirtyDaysAgo
    })

    const reorderSuggestions = products
      .map((product) => {
        const totalSold = last30Days.reduce((sum, sale) => {
          const item = sale.productos.find((p) => p.id === product.id)
          return sum + (item?.cantidad || 0)
        }, 0)

        const dailyVelocity = totalSold / 30
        const daysOfInventory = dailyVelocity > 0 ? product.stock / dailyVelocity : Number.POSITIVE_INFINITY

        let urgency: "critical" | "high" | "medium" = "medium"
        let recommendedOrder = 0

        if (daysOfInventory < 3) {
          urgency = "critical"
          recommendedOrder = Math.ceil(dailyVelocity * 30)
        } else if (daysOfInventory < 7) {
          urgency = "high"
          recommendedOrder = Math.ceil(dailyVelocity * 14)
        } else {
          recommendedOrder = Math.ceil(dailyVelocity * 7)
        }

        return {
          productName: product.nombre,
          currentStock: product.stock,
          recommendedOrder,
          urgency,
        }
      })
      .filter((item) => item.recommendedOrder > 0)
      .sort((a, b) => {
        const urgencyOrder = { critical: 0, high: 1, medium: 2 }
        return urgencyOrder[a.urgency] - urgencyOrder[b.urgency]
      })

    return reorderSuggestions
  } catch (error) {
    console.error("[SmartPOS] Error recommending reordering:", error)
    return []
  }
}
