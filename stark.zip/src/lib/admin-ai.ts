// Administrative AI Assistant
// Provides insights and automation for business management

import { getAllData, STORES, type Sale, type Product, type Appointment, type Vehicle } from "./db"

export interface AdminInsight {
  title: string
  description: string
  priority: "critical" | "high" | "medium" | "low"
  actionRequired?: boolean
  suggestedAction?: string
}

export interface BusinessRecommendation {
  category: string
  recommendation: string
  expectedImpact: string
}

// Comprehensive admin dashboard analysis
export const generateAdminReport = async (): Promise<{
  insights: AdminInsight[]
  recommendations: BusinessRecommendation[]
  performanceScore: number
}> => {
  try {
    const [sales, products, appointments, vehicles] = await Promise.all([
      getAllData<Sale>(STORES.SALES),
      getAllData<Product>(STORES.PRODUCTS),
      getAllData<Appointment>(STORES.APPOINTMENTS),
      getAllData<Vehicle>(STORES.VEHICLES),
    ])

    const insights: AdminInsight[] = []
    const recommendations: BusinessRecommendation[] = []
    let performanceScore = 100

    // Sales Performance
    if (sales.length === 0) {
      insights.push({
        title: "Sin ventas registradas",
        description: "No hay ventas en el sistema",
        priority: "high",
        actionRequired: true,
      })
      performanceScore -= 20
    } else {
      const totalRevenue = sales.reduce((sum, s) => sum + s.total, 0)
      const avgTicket = totalRevenue / sales.length

      insights.push({
        title: "Desempeño de Ventas",
        description: `${sales.length} ventas generadas. Ingresos totales: RD$${totalRevenue.toLocaleString("es-DO")}`,
        priority: "low",
      })

      if (avgTicket < 500) {
        recommendations.push({
          category: "Ventas",
          recommendation: "Implementar sugerencias de productos complementarios",
          expectedImpact: "Aumentar ticket promedio 15-20%",
        })
      }
    }

    // Inventory Health
    const zeroStock = products.filter((p) => p.stock === 0)
    const lowStock = products.filter((p) => p.stock > 0 && p.stock < 5)

    if (zeroStock.length > 0) {
      insights.push({
        title: "Productos sin stock",
        description: `${zeroStock.length} producto(s) sin inventario`,
        priority: "critical",
        actionRequired: true,
        suggestedAction: "Reabastecer inmediatamente",
      })
      performanceScore -= 15
    }

    if (lowStock.length > 0) {
      insights.push({
        title: "Stock bajo",
        description: `${lowStock.length} producto(s) con inventario bajo`,
        priority: "high",
        actionRequired: true,
      })
      performanceScore -= 10
    }

    if (zeroStock.length === 0 && lowStock.length === 0) {
      insights.push({
        title: "Inventario saludable",
        description: "Todos los productos en niveles adecuados",
        priority: "low",
      })
    }

    // Appointment Management
    if (appointments.length === 0) {
      recommendations.push({
        category: "Barbería",
        recommendation: "Promocionar servicios de barbería",
        expectedImpact: "Aumentar número de citas",
      })
    }

    // Vehicle Processing
    const totalVehicleRevenue = vehicles.reduce((sum, v) => sum + v.precio, 0)
    if (totalVehicleRevenue > 0) {
      insights.push({
        title: "Car Wash Performance",
        description: `${vehicles.length} vehículos procesados. Ingresos: RD$${totalVehicleRevenue.toLocaleString("es-DO")}`,
        priority: "low",
      })
    }

    // General Recommendations
    if (products.length < 10) {
      recommendations.push({
        category: "Inventario",
        recommendation: "Expandir catálogo de productos",
        expectedImpact: "Mayor variedad para clientes",
      })
    }

    recommendations.push({
      category: "General",
      recommendation: "Mantener registros actualizados diariamente",
      expectedImpact: "Mejor análisis y predicciones",
    })

    return {
      insights: insights.sort(
        (a, b) =>
          ["critical", "high", "medium", "low"].indexOf(a.priority) -
          ["critical", "high", "medium", "low"].indexOf(b.priority),
      ),
      recommendations,
      performanceScore: Math.max(0, performanceScore),
    }
  } catch (error) {
    console.error("[AdminAI] Error generating report:", error)
    return { insights: [], recommendations: [], performanceScore: 0 }
  }
}

// Automated daily reports
export const generateDailyReport = async (): Promise<string> => {
  try {
    const [sales, appointments, vehicles] = await Promise.all([
      getAllData<Sale>(STORES.SALES),
      getAllData<Appointment>(STORES.APPOINTMENTS),
      getAllData<Vehicle>(STORES.VEHICLES),
    ])

    const today = new Date().toISOString().split("T")[0]
    const todaySales = sales.filter((s) => s.fecha === today)
    const todayAppointments = appointments.filter((a) => a.fecha === today)
    const todayVehicles = vehicles.filter((v) => v.fecha === today)

    const totalRevenue = todaySales.reduce((sum, s) => sum + s.total, 0)
    const totalExpenses = 0 // TODO: Implement expenses tracking

    let report = `REPORTE DEL DÍA - ${new Date().toLocaleDateString("es-DO")}\n`
    report += `=====================================\n\n`
    report += `VENTAS:\n`
    report += `  Transacciones: ${todaySales.length}\n`
    report += `  Ingresos: RD$${totalRevenue.toLocaleString("es-DO")}\n\n`
    report += `BARBERÍA:\n`
    report += `  Citas: ${todayAppointments.length}\n\n`
    report += `CAR WASH:\n`
    report += `  Vehículos: ${todayVehicles.length}\n`
    report += `  Ingresos: RD$${todayVehicles.reduce((sum, v) => sum + v.precio, 0).toLocaleString("es-DO")}\n`

    return report
  } catch (error) {
    console.error("[AdminAI] Error generating daily report:", error)
    return "Error generando reporte"
  }
}

// Predictive business metrics
export const predictNextWeekTrends = async (): Promise<{
  predictedRevenue: number
  expectedTransactions: number
  busyDays: string[]
}> => {
  try {
    const sales = await getAllData<Sale>(STORES.SALES)

    if (sales.length < 7) {
      return {
        predictedRevenue: 0,
        expectedTransactions: 0,
        busyDays: [],
      }
    }

    // Analyze last 30 days
    const last30Days = sales.filter((s) => {
      const saleDate = new Date(s.fecha)
      const thirtyDaysAgo = new Date()
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)
      return saleDate >= thirtyDaysAgo
    })

    const avgDailyRevenue = last30Days.reduce((sum, s) => sum + s.total, 0) / 30
    const avgDailyTransactions = last30Days.length / 30

    // Analyze day of week patterns
    const dayPatterns: Record<number, { revenue: number; count: number }> = {}
    last30Days.forEach((sale) => {
      const day = new Date(sale.fecha).getDay()
      if (!dayPatterns[day]) {
        dayPatterns[day] = { revenue: 0, count: 0 }
      }
      dayPatterns[day].revenue += sale.total
      dayPatterns[day].count++
    })

    const busyDays = Object.entries(dayPatterns)
      .sort(([, a], [, b]) => b.revenue - a.revenue)
      .slice(0, 2)
      .map(([day]) => {
        const dayNames = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sab"]
        return dayNames[Number(day)]
      })

    return {
      predictedRevenue: Math.ceil(avgDailyRevenue * 7),
      expectedTransactions: Math.ceil(avgDailyTransactions * 7),
      busyDays,
    }
  } catch (error) {
    console.error("[AdminAI] Error predicting trends:", error)
    return { predictedRevenue: 0, expectedTransactions: 0, busyDays: [] }
  }
}
