"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Lightbulb, TrendingUp, AlertTriangle, Zap, Brain, BarChart3, Package } from "lucide-react"
import { generatePredictions, getAdminInsights } from "@/lib/jarvis-ai"
import { calculateMetrics } from "@/lib/business-analytics"

export function JarvisPanel() {
  const [predictions, setPredictions] = useState<any>(null)
  const [insights, setInsights] = useState<any>(null)
  const [metrics, setMetrics] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    loadData()
    const interval = setInterval(loadData, 30000) // Refresh every 30 seconds
    return () => clearInterval(interval)
  }, [])

  const loadData = async () => {
    setIsLoading(true)
    try {
      const [pred, adm, met] = await Promise.all([generatePredictions(), getAdminInsights(), calculateMetrics()])
      setPredictions(pred)
      setInsights(adm)
      setMetrics(met)
    } catch (error) {
      console.error("Error loading Jarvis panel data:", error)
    }
    setIsLoading(false)
  }

  if (isLoading || !predictions || !insights || !metrics) {
    return (
      <Card className="glass">
        <CardContent className="pt-6">
          <div className="text-center text-muted-foreground">
            <Brain className="w-8 h-8 mx-auto mb-2 animate-pulse" />
            Analizando datos...
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Tabs defaultValue="analytics" className="space-y-4">
      <TabsList className="grid w-full grid-cols-3 glass">
        <TabsTrigger value="analytics" className="gap-2">
          <BarChart3 className="w-4 h-4" />
          Analítica
        </TabsTrigger>
        <TabsTrigger value="predictions" className="gap-2">
          <Brain className="w-4 h-4" />
          Predicciones
        </TabsTrigger>
        <TabsTrigger value="alerts" className="gap-2">
          <AlertTriangle className="w-4 h-4" />
          Alertas
        </TabsTrigger>
      </TabsList>

      {/* Analytics Tab */}
      <TabsContent value="analytics" className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <Card className="glass">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-success" />
                Ingresos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">RD${metrics.revenue.toLocaleString("es-DO")}</p>
              <p className="text-xs text-muted-foreground">{metrics.salesCount} ventas</p>
            </CardContent>
          </Card>

          <Card className="glass">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Zap className="w-4 h-4 text-primary" />
                Promedio
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">
                RD${metrics.avgTicket.toLocaleString("es-DO", { maximumFractionDigits: 0 })}
              </p>
              <p className="text-xs text-muted-foreground">Por transacción</p>
            </CardContent>
          </Card>
        </div>

        {/* Top Products */}
        <Card className="glass">
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <Package className="w-4 h-4" />
              Productos Top
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {metrics.topProducts.map((product: any, idx: number) => (
                <div key={idx} className="flex items-center justify-between text-sm">
                  <span className="truncate">{product.name}</span>
                  <Badge variant="outline">{product.quantity}u</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      {/* Predictions Tab */}
      <TabsContent value="predictions" className="space-y-4">
        <Card className="glass">
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-yellow-500" />
              Próximos Productos Populares
            </CardTitle>
          </CardHeader>
          <CardContent>
            {predictions.nextPopularProduct ? (
              <Badge className="bg-primary">{predictions.nextPopularProduct}</Badge>
            ) : (
              <p className="text-sm text-muted-foreground">Sin datos suficientes</p>
            )}
          </CardContent>
        </Card>

        <Card className="glass">
          <CardHeader>
            <CardTitle className="text-sm">Horas Pico</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2 flex-wrap">
              {predictions.peakHours.map((hour: string, idx: number) => (
                <Badge key={idx} variant="outline">
                  {hour}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      {/* Alerts Tab */}
      <TabsContent value="alerts" className="space-y-4">
        {insights.alerts.length > 0 ? (
          <div className="space-y-2">
            {insights.alerts.map((alert: string, idx: number) => (
              <Card key={idx} className="glass border-destructive/50 bg-destructive/10">
                <CardContent className="pt-4 flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
                  <p className="text-sm">{alert}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="glass">
            <CardContent className="pt-6">
              <p className="text-sm text-center text-muted-foreground">Todo está bajo control. ¡Buena jornada!</p>
            </CardContent>
          </Card>
        )}
      </TabsContent>

      <Button onClick={loadData} variant="outline" className="w-full bg-transparent" size="sm">
        Actualizar Análisis
      </Button>
    </Tabs>
  )
}
