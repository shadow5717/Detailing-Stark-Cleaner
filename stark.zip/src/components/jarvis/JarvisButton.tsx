"use client"

import { useState, useEffect } from "react"
import { Mic, MicOff, Volume2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { getVoiceManager, type VoiceState } from "@/lib/voice-manager"
import { cn } from "@/lib/utils"

interface JarvisButtonProps {
  onCommandExecuted?: (data: any) => void
  onNavigate?: (module: string, tab?: string) => void
}

export function JarvisButton({ onCommandExecuted, onNavigate }: JarvisButtonProps) {
  const [isListening, setIsListening] = useState(false)
  const [transcript, setTranscript] = useState("")
  const [isResponding, setIsResponding] = useState(false)
  const voiceManager = getVoiceManager()

  useEffect(() => {
    // Listen to voice manager events
    const handleStateChange = (state: VoiceState) => {
      setIsListening(state.isListening)
      setTranscript(state.transcript)
    }

    const handleCommandExecuted = (data: any) => {
      setIsResponding(true)
      if (data.response?.action === "navigate" && onNavigate) {
        const { module, tab } = data.response.data
        onNavigate(module, tab)
      }
      if (onCommandExecuted) {
        onCommandExecuted(data)
      }
      setTimeout(() => setIsResponding(false), 1500)
    }

    voiceManager.on("state-changed", handleStateChange)
    voiceManager.on("command-executed", handleCommandExecuted)

    return () => {
      voiceManager.off("state-changed", handleStateChange)
      voiceManager.off("command-executed", handleCommandExecuted)
    }
  }, [voiceManager, onCommandExecuted, onNavigate])

  const handleToggle = () => {
    voiceManager.toggleListening()
  }

  return (
    <div className="fixed bottom-8 right-8 z-50 flex flex-col items-end gap-3">
      {/* Transcript Display */}
      {transcript && (
        <div className="bg-primary text-primary-foreground rounded-xl px-4 py-3 max-w-xs animate-slide-in-up shadow-lg">
          <p className="text-sm font-medium">{transcript}</p>
        </div>
      )}

      {/* Status Indicator */}
      {isListening && (
        <div className="text-sm text-muted-foreground flex items-center gap-2 px-3 py-2 bg-secondary/50 rounded-lg animate-pulse">
          <Volume2 className="w-4 h-4 text-primary animate-bounce" />
          Escuchando...
        </div>
      )}

      {/* Main Button */}
      <Button
        onClick={handleToggle}
        className={cn(
          "w-16 h-16 rounded-full shadow-lg hover:shadow-xl transition-all",
          isListening && "animate-pulse bg-destructive hover:bg-destructive/90",
          isResponding && "bg-success hover:bg-success/90",
        )}
        disabled={isResponding}
      >
        {isResponding ? (
          <Volume2 className="w-6 h-6 animate-bounce" />
        ) : isListening ? (
          <MicOff className="w-6 h-6" />
        ) : (
          <Mic className="w-6 h-6" />
        )}
      </Button>

      {/* Tooltip */}
      <div className="text-xs text-muted-foreground bg-secondary/50 px-3 py-2 rounded-lg">
        {isListening ? "Hablando..." : "Toca para hablar"}
      </div>
    </div>
  )
}
