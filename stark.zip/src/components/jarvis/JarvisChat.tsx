"use client"

import { useState, useEffect, useRef } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { parseCommand, executeCommand, speak } from "@/lib/jarvis-ai"
import { Send } from "lucide-react"

interface ChatMessage {
  id: string
  role: "user" | "jarvis"
  text: string
  timestamp: Date
}

export function JarvisChat() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "0",
      role: "jarvis",
      text: "Hola, soy Jarvis. ¿Cómo puedo ayudarte hoy?",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Auto-scroll to bottom
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages])

  const handleSendMessage = async (text: string) => {
    if (!text.trim()) return

    setIsProcessing(true)

    // Add user message
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      text,
      timestamp: new Date(),
    }
    setMessages((prev) => [...prev, userMessage])
    setInput("")

    try {
      // Parse and execute command
      const command = parseCommand(text)
      const response = await executeCommand(command)

      // Add Jarvis response
      const jarvisMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: "jarvis",
        text: response.text,
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, jarvisMessage])

      // Speak response
      if (response.shouldSpeak !== false) {
        speak(response.text)
      }
    } catch (error) {
      console.error("Error processing message:", error)
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: "jarvis",
        text: "Disculpa, ocurrió un error procesando tu comando.",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, errorMessage])
    }

    setIsProcessing(false)
  }

  return (
    <Card className="glass h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-success animate-pulse" />
          <h3 className="font-semibold">Jarvis - Chat</h3>
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-xs px-4 py-2 rounded-lg ${
                msg.role === "user" ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"
              }`}
            >
              <p className="text-sm">{msg.text}</p>
              <p className="text-xs opacity-70 mt-1">
                {msg.timestamp.toLocaleTimeString("es-DO", {
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </p>
            </div>
          </div>
        ))}
        {isProcessing && (
          <div className="flex justify-start">
            <Badge variant="outline" className="animate-pulse">
              Procesando...
            </Badge>
          </div>
        )}
      </div>

      {/* Input */}
      <div className="p-4 border-t border-border space-y-2">
        <div className="flex gap-2">
          <Input
            placeholder="Escribe un comando..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSendMessage(input)}
            disabled={isProcessing}
          />
          <Button size="icon" onClick={() => handleSendMessage(input)} disabled={!input.trim() || isProcessing}>
            <Send className="w-4 h-4" />
          </Button>
        </div>
        <p className="text-xs text-muted-foreground text-center">Intenta: "Abre el POS" o "Agenda una cita"</p>
      </div>
    </Card>
  )
}
